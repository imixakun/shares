from tkinter import *
import webview

tk = Tk()
tk.geometry('800x450')

webview.create_window("Tkinter web UI app", 'design/index.html')
webview.start()

# t.me/mikey_developer
